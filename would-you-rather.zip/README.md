
# Would You Rather Project
## project
This project was build using react with redux library to mange the state of the whole application 


# Installation 
`npm install`

# Run
`yarn start` or npm start

Open https://localhost:3000 to view it in the browser
